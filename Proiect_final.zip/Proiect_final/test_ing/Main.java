
class A{}
class B extends A{}
class C extends B{}

public class Main {
    public static void main(String[] args) {
        B b =  new B();
    }
}
