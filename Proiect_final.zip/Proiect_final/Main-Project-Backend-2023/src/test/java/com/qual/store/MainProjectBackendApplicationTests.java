package com.qual.store;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled
class MainProjectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
