package com.qual.store.model.enums;

public enum OrderStatus {
    ACTIVE, CHECKOUT, PLACED, SHIPPED, DELIVERED, CANCELLED
}
