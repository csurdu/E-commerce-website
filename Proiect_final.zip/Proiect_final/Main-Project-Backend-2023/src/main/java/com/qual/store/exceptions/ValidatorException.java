package com.qual.store.exceptions;

public class ValidatorException extends ShopException {
    public ValidatorException(String message) {
        super(message);
    }
}
