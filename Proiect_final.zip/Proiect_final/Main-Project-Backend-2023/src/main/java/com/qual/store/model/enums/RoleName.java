package com.qual.store.model.enums;

public enum RoleName {
    USER, ADMIN
}
