package com.qual.store.exceptions;

public class OrderItemNotFoundException extends ShopException {
    public OrderItemNotFoundException(String message) {
        super(message);
    }
}
