package com.qual.store.exceptions;

public class OrderNotFoundException extends ShopException {
    public OrderNotFoundException(String message) {
        super(message);
    }
}
