package com.qual.store.exceptions;

public class ShopException extends RuntimeException {
    public ShopException(String message) {
        super(message);
    }
}
